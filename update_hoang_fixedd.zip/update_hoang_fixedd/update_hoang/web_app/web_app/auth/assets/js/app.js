// ===== DEBUG HELPER =====
function debug(msg) {
  console.log('[DEBUG]', msg);
}

// ===== STATE MANAGEMENT =====
const authState = {
    selectedRole: 'admin',
    failedAttempts: {},
    lockoutDuration: 15 * 60 * 1000, // 15 minutes
    maxAttempts: 5,
    
    init() {
        debug('Initializing auth state...');
        
        // Load saved role
        const savedRole = localStorage.getItem('aes_selected_role') || 'admin';
        this.selectedRole = savedRole;
        this.updateRoleSelection(savedRole, 'login');
        this.updateRoleSelection(savedRole, 'register');
        
        // Load failed attempts
        const savedAttempts = localStorage.getItem('aes_failed_attempts');
        if (savedAttempts) {
            try {
                this.failedAttempts = JSON.parse(savedAttempts);
                this.cleanupExpiredLockouts();
            } catch (e) {
                console.error('Failed to parse failed attempts:', e);
                this.failedAttempts = {};
            }
        }
        
        // Initialize demo users
        this.initDemoUsers();
        
        debug('Auth state initialized:', {
            selectedRole: this.selectedRole,
            failedAttempts: this.failedAttempts
        });
    },
    
    selectRole(role, formType = 'login') {
        debug(`Selecting role: ${role} for ${formType} form`);
        this.selectedRole = role;
        localStorage.setItem('aes_selected_role', role);
        this.updateRoleSelection(role, formType);
        showToast(`Đã chọn vai trò: ${this.getRoleName(role)}`, 'success');
    },
    
    getRoleName(role) {
        const roles = {
            admin: 'Quản trị viên',
            mentor: 'Mentor',
            learner: 'Người học'
        };
        return roles[role] || role;
    },
    
    updateRoleSelection(role, formType) {
        debug(`Updating role selection to ${role} for ${formType} form`);
        const formSelector = formType === 'register' ? '#registerForm' : '#loginForm';
        document.querySelectorAll(`${formSelector} .role`).forEach(btn => {
            const isActive = btn.dataset.role === role;
            btn.classList.toggle('active', isActive);
            btn.setAttribute('aria-checked', isActive ? 'true' : 'false');
        });
    },
    
    isAccountLocked(email) {
        const account = this.failedAttempts[email];
        if (!account) return false;
        
        const now = Date.now();
        if (account.lockedUntil && now < account.lockedUntil) {
            debug(`Account ${email} is locked until ${new Date(account.lockedUntil)}`);
            return true;
        }
        
        if (account.lockedUntil && now >= account.lockedUntil) {
            debug(`Account ${email} lockout expired, resetting...`);
            delete this.failedAttempts[email];
            this.saveAttempts();
            return false;
        }
        
        return false;
    },
    
    recordFailedAttempt(email) {
        const now = Date.now();
        
        if (!this.failedAttempts[email]) {
            this.failedAttempts[email] = {
                count: 0,
                firstAttempt: now
            };
        }
        
        const account = this.failedAttempts[email];
        account.count++;
        
        if (account.count >= this.maxAttempts) {
            account.lockedUntil = now + this.lockoutDuration;
            debug(`Account ${email} locked until ${new Date(account.lockedUntil)}`);
        }
        
        this.saveAttempts();
        return account;
    },
    
    resetFailedAttempts(email) {
        if (this.failedAttempts[email]) {
            debug(`Resetting failed attempts for ${email}`);
            delete this.failedAttempts[email];
            this.saveAttempts();
        }
    },
    
    saveAttempts() {
        try {
            localStorage.setItem('aes_failed_attempts', JSON.stringify(this.failedAttempts));
            debug('Failed attempts saved:', this.failedAttempts);
        } catch (e) {
            console.error('Failed to save attempts:', e);
        }
    },
    
    cleanupExpiredLockouts() {
        const now = Date.now();
        let changed = false;
        
        for (const email in this.failedAttempts) {
            const account = this.failedAttempts[email];
            if (account.lockedUntil && now >= account.lockedUntil) {
                debug(`Cleaning up expired lockout for ${email}`);
                delete this.failedAttempts[email];
                changed = true;
            }
        }
        
        if (changed) {
            this.saveAttempts();
        }
    },
    
    initDemoUsers() {
        if (!localStorage.getItem('aes_users')) {
            debug('Initializing demo users...');
            const demoUsers = {
                'admin@aes.com': {
                    password: 'admin123',
                    name: 'Admin User',
                    role: 'admin',
                    isActive: true,
                    createdAt: new Date().toISOString()
                },
                'mentor@aes.com': {
                    password: 'mentor123',
                    name: 'Mentor User',
                    role: 'mentor',
                    isActive: true,
                    createdAt: new Date().toISOString()
                },
                'learner@aes.com': {
                    password: 'learner123',
                    name: 'Learner User',
                    role: 'learner',
                    isActive: true,
                    createdAt: new Date().toISOString()
                }
            };
            localStorage.setItem('aes_users', JSON.stringify(demoUsers));
            debug('Demo users initialized');
        } else {
            debug('Demo users already exist');
        }
    }
};

// ===== DOM ELEMENTS =====
const elements = {
    // Role selection
    loginRoles: null,
    registerRoles: null,
    
    // Form toggles
    toggleRegisterBtn: null,
    showRegisterLink: null,
    showLoginLink: null,
    
    // Login form
    loginForm: null,
    loginEmail: null,
    loginPassword: null,
    toggleLoginPassword: null,
    
    // Register form
    registerForm: null,
    registerName: null,
    registerEmail: null,
    registerPassword: null,
    confirmPassword: null,
    toggleRegisterPassword: null,
    toggleConfirmPassword: null,
    
    // Forgot password
    forgotPasswordLink: null,
    forgotModal: null,
    closeForgotModal: null,
    forgotEmail: null,
    resetPasswordBtn: null,
    
    // Locked message
    lockedMessage: null,
    
    // Toast
    toast: null
};

// ===== INIT DOM ELEMENTS =====
function initElements() {
    debug('Initializing DOM elements...');
    
    // Role selection
    elements.loginRoles = document.querySelectorAll('#loginForm .role');
    elements.registerRoles = document.querySelectorAll('#registerForm .role');
    
    // Form toggles
    elements.toggleRegisterBtn = document.getElementById('toggleRegisterBtn');
    elements.showRegisterLink = document.getElementById('showRegisterLink');
    elements.showLoginLink = document.getElementById('showLoginLink');
    
    // Login form
    elements.loginForm = document.getElementById('loginForm');
    elements.loginEmail = document.getElementById('loginEmail');
    elements.loginPassword = document.getElementById('loginPassword');
    elements.toggleLoginPassword = document.getElementById('toggleLoginPassword');
    
    // Register form
    elements.registerForm = document.getElementById('registerForm');
    elements.registerName = document.getElementById('registerName');
    elements.registerEmail = document.getElementById('registerEmail');
    elements.registerPassword = document.getElementById('registerPassword');
    elements.confirmPassword = document.getElementById('confirmPassword');
    elements.toggleRegisterPassword = document.getElementById('toggleRegisterPassword');
    elements.toggleConfirmPassword = document.getElementById('toggleConfirmPassword');
    
    // Forgot password
    elements.forgotPasswordLink = document.getElementById('forgotPasswordLink');
    elements.forgotModal = document.getElementById('forgotModal');
    elements.closeForgotModal = document.getElementById('closeForgotModal');
    elements.forgotEmail = document.getElementById('forgotEmail');
    elements.resetPasswordBtn = document.getElementById('resetPasswordBtn');
    
    // Locked message
    elements.lockedMessage = document.getElementById('lockedMessage');
    
    // Toast
    elements.toast = document.getElementById('toast');
    
    // Validate all elements loaded
    const missing = Object.entries(elements).filter(([key, val]) => !val);
    if (missing.length > 0) {
        console.error('Missing DOM elements:', missing.map(([k]) => k));
        alert('Lỗi khởi tạo hệ thống. Vui lòng refresh trang.');
    } else {
        debug('All DOM elements initialized successfully');
    }
}

// ===== EVENT LISTENERS =====
function initEventListeners() {
    debug('Initializing event listeners...');
    
    // Role selection for login form
    elements.loginRoles.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            authState.selectRole(btn.dataset.role, 'login');
        });
    });
    
    // Role selection for register form
    elements.registerRoles.forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            e.stopPropagation();
            authState.selectRole(btn.dataset.role, 'register');
        });
    });
    
    // Form toggling
    elements.toggleRegisterBtn.addEventListener('click', showRegisterForm);
    elements.showRegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        showRegisterForm();
    });
    elements.showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        showLoginForm();
    });
    
    // Password visibility toggle
    elements.toggleLoginPassword.addEventListener('click', (e) => {
        e.preventDefault();
        togglePasswordVisibility(elements.loginPassword);
    });
    
    elements.toggleRegisterPassword.addEventListener('click', (e) => {
        e.preventDefault();
        togglePasswordVisibility(elements.registerPassword);
    });
    
    elements.toggleConfirmPassword.addEventListener('click', (e) => {
        e.preventDefault();
        togglePasswordVisibility(elements.confirmPassword);
    });
    
    // Forgot password
    elements.forgotPasswordLink.addEventListener('click', (e) => {
        e.preventDefault();
        elements.forgotModal.classList.add('show');
    });
    
    elements.closeForgotModal.addEventListener('click', (e) => {
        e.preventDefault();
        elements.forgotModal.classList.remove('show');
    });
    
    // Close modal when clicking outside
    window.addEventListener('click', (e) => {
        if (e.target === elements.forgotModal) {
            elements.forgotModal.classList.remove('show');
        }
    });
    
    // Form submissions
    elements.loginForm.addEventListener('submit', handleLogin);
    elements.registerForm.addEventListener('submit', handleRegister);
    elements.resetPasswordBtn.addEventListener('click', handleForgotPassword);
    
    debug('All event listeners initialized successfully');
}

// ===== HELPER FUNCTIONS =====
function togglePasswordVisibility(input) {
    debug('Toggling password visibility for:', input.id);
    
    const button = input.nextElementSibling;
    if (!button) {
        console.error('Password toggle button not found for input:', input.id);
        return;
    }
    
    const icon = button.querySelector('i');
    if (!icon) {
        console.error('Password toggle icon not found');
        return;
    }
    
    if (input.type === 'password') {
        input.type = 'text';
        icon.classList.remove('fa-eye');
        icon.classList.add('fa-eye-slash');
    } else {
        input.type = 'password';
        icon.classList.remove('fa-eye-slash');
        icon.classList.add('fa-eye');
    }
}

function showToast(message, type = 'info') {
    if (!elements.toast) {
        console.error('Toast element not found');
        alert(message);
        return;
    }
    
    elements.toast.textContent = message;
    elements.toast.className = `toast show ${type}`;
    
    setTimeout(() => {
        elements.toast.classList.remove('show');
    }, 3000);
}

function showLockedMessage(email) {
    const account = authState.failedAttempts[email];
    if (!account || !account.lockedUntil) return;
    
    const remaining = Math.ceil((account.lockedUntil - Date.now()) / 60000);
    elements.lockedMessage.textContent = `🔒 Tài khoản bị khóa do nhập sai mật khẩu quá ${authState.maxAttempts} lần. Vui lòng thử lại sau ${remaining} phút.`;
    elements.lockedMessage.style.display = 'block';
    
    // Disable login button
    const loginBtn = elements.loginForm.querySelector('button[type="submit"]');
    if (loginBtn) {
        loginBtn.disabled = true;
        loginBtn.style.opacity = '0.6';
        loginBtn.style.cursor = 'not-allowed';
    }
    
    // Re-enable after lockout period
    setTimeout(() => {
        elements.lockedMessage.style.display = 'none';
        if (loginBtn) {
            loginBtn.disabled = false;
            loginBtn.style.opacity = '1';
            loginBtn.style.cursor = 'pointer';
        }
        authState.resetFailedAttempts(email);
    }, account.lockedUntil - Date.now());
}

function showLoginForm() {
    debug('Showing login form');
    elements.loginForm.style.display = 'flex';
    elements.registerForm.style.display = 'none';
    document.querySelector('.topbar .btn-secondary').textContent = 'Đăng ký';
    document.querySelector('.topbar .btn-secondary').onclick = showRegisterForm;
}

function showRegisterForm() {
    debug('Showing register form');
    elements.loginForm.style.display = 'none';
    elements.registerForm.style.display = 'flex';
    document.querySelector('.topbar .btn-secondary').textContent = 'Đăng nhập';
    document.querySelector('.topbar .btn-secondary').onclick = showLoginForm;
}

// ===== AUTH FUNCTIONS =====
function handleLogin(e) {
    e.preventDefault();
    debug('Handling login...');
    
    const email = elements.loginEmail.value.trim().toLowerCase();
    const password = elements.loginPassword.value;
    const selectedRole = authState.selectedRole;
    
    debug('Login attempt:', { email, password: '***', selectedRole });
    
    // Check if account is locked
    if (authState.isAccountLocked(email)) {
        showLockedMessage(email);
        return;
    }
    
    // Validate inputs
    if (!email || !password) {
        showToast('Vui lòng nhập đầy đủ email và mật khẩu', 'error');
        return;
    }
    
    // Get users from localStorage
    let users = {};
    try {
        users = JSON.parse(localStorage.getItem('aes_users') || '{}');
    } catch (e) {
        console.error('Failed to parse users:', e);
        showToast('Lỗi hệ thống. Vui lòng thử lại sau.', 'error');
        return;
    }
    
    const user = users[email];
    
    // Check if user exists
    if (!user) {
        recordFailedAttempt(email);
        showToast('Email hoặc mật khẩu không đúng', 'error');
        return;
    }
    
    // Check if account is active
    if (!user.isActive) {
        showToast('Tài khoản của bạn đã bị vô hiệu hóa. Vui lòng liên hệ quản trị viên.', 'error');
        return;
    }
    
    // Check password
    if (user.password !== password) {
        recordFailedAttempt(email);
        showToast('Email hoặc mật khẩu không đúng', 'error');
        return;
    }
    
    // Check role match
    if (user.role !== selectedRole) {
        showToast(`Tài khoản này không có quyền ${authState.getRoleName(selectedRole)}`, 'error');
        return;
    }
    
    // Reset failed attempts on success
    authState.resetFailedAttempts(email);
    
    // Save login session
    const session = {
        email: email,
        name: user.name,
        role: user.role,
        loginTime: new Date().toISOString()
    };
    localStorage.setItem('aes_session', JSON.stringify(session));
    
    // Redirect to appropriate dashboard
    showToast(`Đăng nhập thành công! Chào mừng ${user.name}`, 'success');
    
    setTimeout(() => {
        const roleMap = {
            admin: '../admin/index.html',
            mentor: '../mentor/index.html',
            learner: '../learner/index.html'
        };
        
        const redirectUrl = roleMap[selectedRole] || '../learner/index.html';
        
        // Check if target file exists (for demo purposes)
        if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
            // For localhost, redirect to admin dashboard directly
            window.location.href = redirectUrl;
        } else {
            // For production, show success message
            alert(`Đăng nhập thành công với vai trò ${authState.getRoleName(selectedRole)}!\nRedirecting to: ${redirectUrl}`);
            window.location.href = redirectUrl;
        }
    }, 1500);
}

function recordFailedAttempt(email) {
    const account = authState.recordFailedAttempt(email);
    
    if (account.count >= authState.maxAttempts) {
        showLockedMessage(email);
        showToast(`Tài khoản bị khóa do nhập sai quá ${authState.maxAttempts} lần. Vui lòng thử lại sau 15 phút.`, 'error');
    } else {
        const remaining = authState.maxAttempts - account.count;
        if (remaining > 0) {
            showToast(`Sai mật khẩu. Bạn còn ${remaining} lần thử.`, 'warning');
        }
    }
}

function handleRegister(e) {
    e.preventDefault();
    debug('Handling registration...');
    
    const name = elements.registerName.value.trim();
    const email = elements.registerEmail.value.trim().toLowerCase();
    const password = elements.registerPassword.value;
    const confirmPassword = elements.confirmPassword.value;
    const selectedRole = authState.selectedRole;
    
    // Validate inputs
    if (!name || !email || !password || !confirmPassword) {
        showToast('Vui lòng nhập đầy đủ thông tin', 'error');
        return;
    }
    
    if (password !== confirmPassword) {
        showToast('Mật khẩu xác nhận không khớp', 'error');
        return;
    }
    
    if (password.length < 6) {
        showToast('Mật khẩu phải có ít nhất 6 ký tự', 'error');
        return;
    }
    
    // Get users from localStorage
    let users = {};
    try {
        users = JSON.parse(localStorage.getItem('aes_users') || '{}');
    } catch (e) {
        console.error('Failed to parse users:', e);
        showToast('Lỗi hệ thống. Vui lòng thử lại sau.', 'error');
        return;
    }
    
    // Check if email already exists
    if (users[email]) {
        showToast('Email đã được đăng ký. Vui lòng sử dụng email khác hoặc đăng nhập.', 'error');
        return;
    }
    
    // Create new user
    users[email] = {
        name: name,
        password: password,
        role: selectedRole,
        isActive: true,
        createdAt: new Date().toISOString(),
        lastLogin: null
    };
    
    localStorage.setItem('aes_users', JSON.stringify(users));
    
    // Automatically login after registration
    const session = {
        email: email,
        name: name,
        role: selectedRole,
        loginTime: new Date().toISOString()
    };
    localStorage.setItem('aes_session', JSON.stringify(session));
    
    showToast('Đăng ký thành công! Chuyển hướng đến trang chủ...', 'success');
    
    setTimeout(() => {
        const roleMap = {
            admin: '../admin/index.html',
            mentor: '../mentor/index.html',
            learner: '../learner/index.html'
        };
        
        const redirectUrl = roleMap[selectedRole] || '../learner/index.html';
        window.location.href = redirectUrl;
    }, 1500);
}

function handleForgotPassword(e) {
    e.preventDefault();
    debug('Handling forgot password...');
    
    const email = elements.forgotEmail.value.trim().toLowerCase();
    
    if (!email) {
        showToast('Vui lòng nhập email của bạn', 'error');
        return;
    }
    
    // Get users from localStorage
    let users = {};
    try {
        users = JSON.parse(localStorage.getItem('aes_users') || '{}');
    } catch (e) {
        console.error('Failed to parse users:', e);
        showToast('Lỗi hệ thống. Vui lòng thử lại sau.', 'error');
        return;
    }
    
    // Check if email exists
    if (!users[email]) {
        showToast('Email không tồn tại trong hệ thống', 'error');
        return;
    }
    
    elements.forgotModal.classList.remove('show');
    showToast('✅ Liên kết khôi phục mật khẩu đã được gửi đến email của bạn!', 'success');
    
    // Reset the form
    elements.forgotEmail.value = '';
}

// ===== INITIALIZE =====
document.addEventListener('DOMContentLoaded', () => {
    debug('DOM fully loaded, initializing app...');
    
    // Initialize DOM elements first
    initElements();
    
    // Then initialize auth state
    authState.init();
    
    // Finally set up event listeners
    initEventListeners();
    
    debug('App fully initialized!');
    
    // Auto-fill demo credentials for testing on localhost
    if (window.location.hostname === 'localhost' || window.location.hostname === '127.0.0.1') {
        debug('Auto-filling demo credentials for localhost');
        elements.loginEmail.value = 'admin@aes.com';
        elements.loginPassword.value = 'admin123';
    }
});