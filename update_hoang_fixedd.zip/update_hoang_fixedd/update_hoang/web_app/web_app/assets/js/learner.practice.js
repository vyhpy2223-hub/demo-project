// assets/js/learner.practice.js
function renderPractice(containerId="learnerPractice") {
  const el = document.getElementById(containerId);
  if (!el) return;

  const topic = getSelectedTopic();
  const script = topic.scripts[0];

  el.innerHTML = `
    <div class="card">
      <h2>4.2 Luyện nói (AI hỗ trợ)</h2>
      <div style="color:#6b7280;font-weight:800;margin:6px 0 12px">
        Chủ đề hiện tại: <b>${topic.title}</b> • Kịch bản: <b>${script.name}</b>
      </div>

      <div class="tile" style="min-height:auto">
        <div style="font-weight:900;margin-bottom:8px">Gợi ý hội thoại</div>
        <ol style="margin:0;padding-left:18px;color:#334155;font-weight:800;line-height:1.7">
          ${script.lines.map(l=>`<li>${l}</li>`).join("")}
        </ol>
      </div>

      <div style="display:flex;gap:10px;flex-wrap:wrap;margin-top:12px">
        <button class="btn" id="btnAi">Luyện với AI (ghi log)</button>
        <button class="btn" id="btnPeer">Luyện với người học khác (demo)</button>
      </div>

      <div id="practiceMsg" style="margin-top:10px;color:#0f766e;font-weight:900"></div>
    </div>
  `;

  function done(mode){
    const minutes = mode==="ai" ? 10 : 15;
    const score = mode==="ai" ? 78 : 72;
    addPracticeLog({ minutes, score, mode });
    document.getElementById("practiceMsg").textContent =
      `✅ Đã lưu lượt luyện (${mode.toUpperCase()}) • ${minutes} phút • score ${score}.`;
    // cập nhật tiến độ & leaderboard
    if (typeof renderProgress === "function") renderProgress();
    if (typeof renderChallenges === "function") renderChallenges();
  }

  el.querySelector("#btnAi").onclick = ()=> done("ai");
  el.querySelector("#btnPeer").onclick = ()=> done("peer");
}
