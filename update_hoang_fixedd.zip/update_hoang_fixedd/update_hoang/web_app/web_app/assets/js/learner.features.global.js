// learner/assets/js/learner.features.global.js
const TOPICS = [
  { id:"t1", title:"Ordering Coffee", level:"A1-A2", scripts:[
    { id:"s1", name:"At the counter", lines:["Hi, can I get a latte?", "Sure. Anything else?", "No, that's all."] },
    { id:"s2", name:"Custom order", lines:["Can I have it less sweet?", "Of course.", "Thanks!"] },
  ]},
  { id:"t2", title:"Job Interview", level:"B1-B2", scripts:[
    { id:"s3", name:"Tell me about yourself", lines:["Tell me about yourself.", "I’m a ...", "Why do you want this role?"] },
    { id:"s4", name:"Strengths & Weaknesses", lines:["What are your strengths?", "My strengths are...", "What about weaknesses?"] },
  ]},
];

const CHALLENGES = [
  { id:"c1", name:"7-day Streak", reward:50, desc:"Giữ streak >= 7 ngày" },
  { id:"c2", name:"100 Minutes", reward:80, desc:"Tổng thời gian >= 100 phút" },
];

function _getTopic(id){ return TOPICS.find(t=>t.id===id) || TOPICS[0]; }
function _calcStreak(logs){
  const set = new Set(logs.map(x=>x.date));
  let streak=0; let d=new Date();
  while(true){
    const key = d.toISOString().slice(0,10);
    if(!set.has(key)) break;
    streak++; d.setDate(d.getDate()-1);
  }
  return streak;
}
function _lastNDays(n=35){
  const arr=[]; const d=new Date();
  for(let i=n-1;i>=0;i--){
    const x=new Date(d); x.setDate(d.getDate()-i);
    arr.push(x.toISOString().slice(0,10));
  }
  return arr;
}

/* 4.1 */
function renderLearnerTopics(mount){
  const data = loadLearnerData();
  const selectedTopic = _getTopic(data.selectedTopicId);

  mount.innerHTML = `
    <div class="card" style="padding:16px">
      <h3 style="margin:0 0 12px">4.1 Chọn chủ đề & kịch bản hội thoại</h3>
      <div style="display:grid;gap:12px">
        ${TOPICS.map(t=>`
          <div class="tile" style="padding:12px;border-radius:14px;border:1px solid #e5e7eb">
            <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
              <div>
                <div style="font-weight:900">${t.title}</div>
                <div style="color:#6b7280;font-weight:800;font-size:13px">Level ${t.level} • ${t.scripts.length} scripts</div>
              </div>
              <button class="btn" data-topic="${t.id}">${t.id===selectedTopic.id ? "Đã chọn" : "Chọn"}</button>
            </div>
            <div style="margin-top:10px;display:grid;gap:8px">
              ${t.scripts.map(s=>`
                <div style="padding:10px;border:1px solid #e5e7eb;border-radius:12px;background:rgba(255,255,255,.75);
                            display:flex;justify-content:space-between;align-items:center;gap:10px">
                  <div><b>${s.name}</b> <span style="color:#6b7280;font-weight:800">(${s.id})</span></div>
                  <button class="btn" data-script="${t.id}:${s.id}">
                    ${(data.selectedTopicId===t.id && data.selectedScriptId===s.id) ? "Đang dùng" : "Dùng"}
                  </button>
                </div>
              `).join("")}
            </div>
          </div>
        `).join("")}
      </div>
    </div>
  `;

  mount.querySelectorAll("[data-topic]").forEach(btn=>{
    btn.onclick = ()=>{
      const tId = btn.getAttribute("data-topic");
      const d2 = loadLearnerData();
      d2.selectedTopicId = tId;
      d2.selectedScriptId = _getTopic(tId).scripts[0].id;
      saveLearnerData(d2);
      renderLearnerTopics(mount);
    };
  });

  mount.querySelectorAll("[data-script]").forEach(btn=>{
    btn.onclick = ()=>{
      const [tId, sId] = btn.getAttribute("data-script").split(":");
      const d2 = loadLearnerData();
      d2.selectedTopicId = tId;
      d2.selectedScriptId = sId;
      saveLearnerData(d2);
      renderLearnerTopics(mount);
    };
  });
}

/* 4.2 */
function renderLearnerPractice(mount){
  const data = loadLearnerData();
  const topic = _getTopic(data.selectedTopicId);
  const script = topic.scripts.find(s=>s.id===data.selectedScriptId) || topic.scripts[0];

  mount.innerHTML = `
    <div class="card" style="padding:16px">
      <h3 style="margin:0 0 12px">4.2 Luyện nói với người học khác (AI hỗ trợ)</h3>
      <div style="color:#6b7280;font-weight:800;margin-bottom:10px">
        Topic: <b>${topic.title}</b> • Script: <b>${script.name}</b>
      </div>

      <div class="tile" style="padding:12px;border-radius:14px;border:1px solid #e5e7eb">
        <div style="font-weight:900;margin-bottom:8px">Gợi ý hội thoại</div>
        <ol style="margin:0;padding-left:18px;font-weight:800;line-height:1.7">
          ${script.lines.map(l=>`<li>${l}</li>`).join("")}
        </ol>
      </div>

      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:12px;align-items:end">
        <div>
          <div style="font-weight:900">Minutes</div>
          <input id="pMin" type="number" value="10" min="1" style="height:38px;border-radius:12px;border:1px solid #e5e7eb;padding:0 10px;font-weight:900;width:120px">
        </div>
        <div>
          <div style="font-weight:900">Score</div>
          <input id="pScore" type="number" value="78" min="0" max="100" style="height:38px;border-radius:12px;border:1px solid #e5e7eb;padding:0 10px;font-weight:900;width:120px">
        </div>
        <button class="btn" id="btnAi">Lưu luyện với AI</button>
        <button class="btn" id="btnPeer">Lưu luyện với bạn học</button>
      </div>

      <div id="practiceMsg" style="margin-top:10px;color:#0f766e;font-weight:900"></div>
    </div>
  `;

  function done(mode){
    const minutes = Math.max(1, parseInt(mount.querySelector("#pMin").value || "10",10));
    const score = Math.max(0, Math.min(100, parseInt(mount.querySelector("#pScore").value || "70",10)));
    addPracticeLog({ minutes, score, mode });
    mount.querySelector("#practiceMsg").textContent = `✅ Đã lưu lượt luyện (${mode.toUpperCase()}) • ${minutes} phút • score ${score}.`;
  }

  mount.querySelector("#btnAi").onclick = ()=>done("ai");
  mount.querySelector("#btnPeer").onclick = ()=>done("peer");
}

/* 4.3 */
function renderLearnerProgress(mount){
  const data = loadLearnerData();
  const logs = data.practiceLogs;

  const streak = _calcStreak(logs);
  const totalMin = logs.reduce((s,x)=>s+(x.minutes||0),0);

  const days = _lastNDays(35);
  const map = new Map();
  logs.forEach(x=>map.set(x.date,(map.get(x.date)||0)+(x.minutes||0)));

  const cells = days.map(d=>{
    const v = map.get(d) || 0;
    const alpha = Math.min(0.85, 0.08 + v/40);
    return `<div title="${d}: ${v} phút"
      style="width:14px;height:14px;border-radius:4px;border:1px solid rgba(229,231,235,.9);
      background:rgba(79,110,247,${alpha});"></div>`;
  }).join("");

  const last7 = days.slice(-7).map(d=>map.get(d)||0);
  const avg7 = Math.round(last7.reduce((a,b)=>a+b,0)/7);

  mount.innerHTML = `
    <div class="card" style="padding:16px">
      <h3 style="margin:0 0 12px">4.3 Theo dõi tiến độ (heatmap, streak, trend)</h3>

      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;flex:1">
          <div style="color:#6b7280;font-weight:900">Streak</div>
          <div style="font-size:28px;font-weight:1000">${streak} 🔥</div>
        </div>
        <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;flex:1">
          <div style="color:#6b7280;font-weight:900">Total Minutes</div>
          <div style="font-size:28px;font-weight:1000">${totalMin}</div>
        </div>
        <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;flex:1">
          <div style="color:#6b7280;font-weight:900">Avg (7 days)</div>
          <div style="font-size:28px;font-weight:1000">${avg7} min/day</div>
        </div>
      </div>

      <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;margin-top:12px">
        <div style="font-weight:1000;margin-bottom:10px">Heatmap (35 ngày)</div>
        <div style="display:grid;grid-template-columns:repeat(7,14px);gap:6px;max-width:max-content">
          ${cells}
        </div>
      </div>
    </div>
  `;
}

/* 4.4 */
function renderLearnerReports(mount){
  const data = loadLearnerData();
  const logs = data.practiceLogs;

  function summary(days){
    const now = new Date();
    const from = new Date();
    from.setDate(now.getDate()-days+1);
    const fromStr = from.toISOString().slice(0,10);
    const slice = logs.filter(x=>x.date >= fromStr);
    const total = slice.reduce((s,x)=>s+(x.minutes||0),0);
    const avgScore = slice.length ? Math.round(slice.reduce((s,x)=>s+(x.score||0),0)/slice.length) : 0;
    return { count:slice.length, total, avgScore, fromStr };
  }

  const w = summary(7);
  const m = summary(30);

  mount.innerHTML = `
    <div class="card" style="padding:16px">
      <h3 style="margin:0 0 12px">4.4 Nhận báo cáo tuần / tháng</h3>

      <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px">
        <b>Weekly (từ ${w.fromStr})</b><br>
        Sessions: <b>${w.count}</b> • Minutes: <b>${w.total}</b> • Avg score: <b>${w.avgScore}</b>
        <div style="margin-top:10px"><button class="btn" id="btnWeekly">Đánh dấu đã nhận báo cáo tuần</button></div>
      </div>

      <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;margin-top:12px">
        <b>Monthly (30 ngày)</b><br>
        Sessions: <b>${m.count}</b> • Minutes: <b>${m.total}</b> • Avg score: <b>${m.avgScore}</b>
        <div style="margin-top:10px"><button class="btn" id="btnMonthly">Đánh dấu đã nhận báo cáo tháng</button></div>
      </div>

      <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;margin-top:12px">
        <b>Trend (7 ngày)</b>
        <canvas id="chart" height="110"></canvas>
      </div>

      <div id="reportMsg" style="margin-top:10px;color:#0f766e;font-weight:900"></div>
    </div>
  `;

  mount.querySelector("#btnWeekly").onclick = ()=>{
    const d2 = loadLearnerData();
    d2.reports.weeklySentAt = new Date().toISOString();
    saveLearnerData(d2);
    mount.querySelector("#reportMsg").textContent = "✅ Đã đánh dấu nhận báo cáo tuần.";
  };

  mount.querySelector("#btnMonthly").onclick = ()=>{
    const d2 = loadLearnerData();
    d2.reports.monthlySentAt = new Date().toISOString();
    saveLearnerData(d2);
    mount.querySelector("#reportMsg").textContent = "✅ Đã đánh dấu nhận báo cáo tháng.";
  };

  const canvas = mount.querySelector("#chart");
  if (!canvas || typeof Chart === "undefined") return;

  if (canvas._chartInstance) { try { canvas._chartInstance.destroy(); } catch {} }

  const days = (() => {
    const arr=[]; const d=new Date();
    for(let i=6;i>=0;i--){
      const x=new Date(d); x.setDate(d.getDate()-i);
      arr.push(x.toISOString().slice(0,10));
    }
    return arr;
  })();

  const map = new Map();
  logs.forEach(x=>map.set(x.date,(map.get(x.date)||0)+(x.minutes||0)));

  const chart = new Chart(canvas, {
    type: "bar",
    data: {
      labels: days.map(d=>d.slice(5)),
      datasets: [{ data: days.map(d=>map.get(d)||0) }]
    },
    options: {
      plugins: { legend: { display: false } },
      scales: { y: { beginAtZero: true } }
    }
  });

  canvas._chartInstance = chart;
}

/* 4.5 */
function renderLearnerChallenges(mount){
  const data = loadLearnerData();
  const logs = data.practiceLogs;
  const totalMin = logs.reduce((s,x)=>s+(x.minutes||0),0);
  const streak = _calcStreak(logs);

  function canClaim(id){
    if (id==="c1") return streak >= 7;
    if (id==="c2") return totalMin >= 100;
    return false;
  }

  mount.innerHTML = `
    <div class="card" style="padding:16px">
      <h3 style="margin:0 0 12px">4.5 Thử thách, bảng xếp hạng, phần thưởng</h3>

      <div style="display:flex;gap:12px;flex-wrap:wrap">
        <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;flex:1">
          <div style="color:#6b7280;font-weight:900">Points</div>
          <div style="font-size:28px;font-weight:1000">${data.challenges.points}</div>
          <div style="color:#6b7280;font-weight:850;margin-top:6px">
            Badges: ${data.challenges.badges.length ? data.challenges.badges.join(", ") : "—"}
          </div>
        </div>
        <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px;flex:2">
          <div style="font-weight:1000">Leaderboard (demo)</div>
          <div style="color:#6b7280;font-weight:850;margin-top:6px;line-height:1.6">
            1) You — <b>${data.challenges.points}</b> pts<br/>
            2) Alex — 120 pts<br/>
            3) Mia — 95 pts
          </div>
        </div>
      </div>

      <div style="display:grid;gap:10px;margin-top:12px">
        ${CHALLENGES.map(ch=>{
          const joined = data.challenges.joined.includes(ch.id);
          const ok = canClaim(ch.id);
          return `
            <div class="tile" style="padding:12px;border:1px solid #e5e7eb;border-radius:14px">
              <div style="display:flex;justify-content:space-between;gap:10px;align-items:center;flex-wrap:wrap">
                <div>
                  <div style="font-weight:1000">${ch.name}</div>
                  <div style="color:#6b7280;font-weight:850">${ch.desc} • Reward +${ch.reward}</div>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                  <button class="btn" data-join="${ch.id}">${joined ? "Đã tham gia" : "Tham gia"}</button>
                  <button class="btn" data-claim="${ch.id}" ${ok ? "" : "disabled"}
                    style="${ok ? "" : "opacity:.55;cursor:not-allowed"}">Nhận thưởng</button>
                </div>
              </div>
            </div>
          `;
        }).join("")}
      </div>

      <div id="chMsg" style="margin-top:10px;color:#0f766e;font-weight:900"></div>
    </div>
  `;

  mount.querySelectorAll("[data-join]").forEach(b=>{
    b.onclick = ()=>{
      const id = b.getAttribute("data-join");
      const d2 = loadLearnerData();
      if (!d2.challenges.joined.includes(id)) d2.challenges.joined.push(id);
      saveLearnerData(d2);
      renderLearnerChallenges(mount);
    };
  });

  mount.querySelectorAll("[data-claim]").forEach(b=>{
    b.onclick = ()=>{
      const id = b.getAttribute("data-claim");
      if (!canClaim(id)) return;

      const ch = CHALLENGES.find(x=>x.id===id);
      if (!ch) return;

      const d2 = loadLearnerData();
      d2.challenges.points += ch.reward;
      d2.challenges.badges.push(ch.name);
      saveLearnerData(d2);

      mount.querySelector("#chMsg").textContent = `🎉 Nhận thưởng: ${ch.name} (+${ch.reward} pts)`;
      renderLearnerChallenges(mount);
    };
  });
}

// expose globals for layout.js checks (optional)
window.renderLearnerTopics = renderLearnerTopics;
window.renderLearnerPractice = renderLearnerPractice;
window.renderLearnerProgress = renderLearnerProgress;
window.renderLearnerReports = renderLearnerReports;
window.renderLearnerChallenges = renderLearnerChallenges;

