// assets/js/learner.challenges.js
const CHALLENGES = [
  { id:"c1", name:"7-day Streak", need:"streak>=7", reward:50 },
  { id:"c2", name:"100 Minutes", need:"minutes>=100", reward:80 },
];

function renderChallenges(containerId="learnerChallenges") {
  const el = document.getElementById(containerId);
  if (!el) return;

  const data = loadLearnerData();
  const logs = data.practiceLogs;
  const totalMin = logs.reduce((s,x)=>s+(x.minutes||0),0);
  const streak = (typeof calcStreak==="function") ? calcStreak(logs) : 0;

  function canClaim(ch){
    if (ch.id==="c1") return streak >= 7;
    if (ch.id==="c2") return totalMin >= 100;
    return false;
  }

  el.innerHTML = `
    <div class="card">
      <h2>4.5 Thử thách • Bảng xếp hạng • Phần thưởng</h2>

      <div style="display:flex;gap:12px;flex-wrap:wrap;margin-top:10px">
        <div class="tile" style="min-height:auto;flex:1">
          <div style="color:#6b7280;font-weight:900">Points</div>
          <div style="font-size:28px;font-weight:1000">${data.challenges.points}</div>
        </div>
        <div class="tile" style="min-height:auto;flex:2">
          <div style="font-weight:1000">Leaderboard (demo)</div>
          <div style="color:#6b7280;font-weight:850;margin-top:6px">
            1) You - ${data.challenges.points} pts<br/>
            2) Alex - 120 pts<br/>
            3) Mia - 95 pts
          </div>
        </div>
      </div>

      <div style="display:grid;gap:10px;margin-top:14px">
        ${CHALLENGES.map(ch=>{
          const joined = data.challenges.joined.includes(ch.id);
          const ok = canClaim(ch);
          return `
            <div class="tile" style="min-height:auto">
              <div style="display:flex;justify-content:space-between;gap:10px;align-items:center">
                <div>
                  <div style="font-weight:1000">${ch.name}</div>
                  <div style="color:#6b7280;font-weight:850">Điều kiện: ${ch.need} • Reward: +${ch.reward} pts</div>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                  <button class="btn" data-join="${ch.id}">${joined?"Đã tham gia":"Tham gia"}</button>
                  <button class="btn" data-claim="${ch.id}" ${ok? "":"disabled"} style="${ok?"":"opacity:.55;cursor:not-allowed"}">Nhận thưởng</button>
                </div>
              </div>
            </div>
          `;
        }).join("")}
      </div>

      <div id="chMsg" style="margin-top:10px;color:#0f766e;font-weight:900"></div>
    </div>
  `;

  el.querySelectorAll("[data-join]").forEach(b=>{
    b.onclick = ()=>{
      const id = b.getAttribute("data-join");
      const d2 = loadLearnerData();
      if (!d2.challenges.joined.includes(id)) d2.challenges.joined.push(id);
      saveLearnerData(d2);
      renderChallenges(containerId);
    };
  });

  el.querySelectorAll("[data-claim]").forEach(b=>{
    b.onclick = ()=>{
      const id = b.getAttribute("data-claim");
      const ch = CHALLENGES.find(x=>x.id===id);
      if (!ch) return;
      if (!canClaim(ch)) return;

      const d2 = loadLearnerData();
      d2.challenges.points += ch.reward;
      d2.challenges.badges.push(ch.name);
      saveLearnerData(d2);
      el.querySelector("#chMsg").textContent = `🎉 Nhận thưởng: ${ch.name} (+${ch.reward} pts)`;
      renderChallenges(containerId);
    };
  });
}
