// Shared auth helpers for AES demo (front-end only)
(function () {
  const STORAGE_KEY_ROLE = "aes_role";
  const STORAGE_KEY_EMAIL = "aes_email";

  function getRole() {
    return localStorage.getItem(STORAGE_KEY_ROLE) || "";
  }

  function setSession(role, email) {
    localStorage.setItem(STORAGE_KEY_ROLE, role);
    if (email) localStorage.setItem(STORAGE_KEY_EMAIL, email);
  }

  function clearSession() {
    localStorage.removeItem(STORAGE_KEY_ROLE);
    localStorage.removeItem(STORAGE_KEY_EMAIL);
  }

  // Redirect to auth page (works with relative paths from anywhere)
  function gotoAuth() {
    // Find project root by walking up to /web_app/ and then /auth/index.html
    // Since this is a static demo, just try a few common relative paths.
    const candidates = [
      "../auth/index.html",
      "../../auth/index.html",
      "../../../auth/index.html",
      "../../../../auth/index.html",
      "auth/index.html"
    ];
    for (const p of candidates) {
      // best-effort: first matching navigation
      try { window.location.href = p; return; } catch (_) {}
    }
  }

  function requireRole(allowed) {
    const role = getRole();
    const ok = Array.isArray(allowed) ? allowed.includes(role) : role === allowed;
    if (!ok) gotoAuth();
  }

  function logout() {
    clearSession();
    gotoAuth();
  }

  // Auto-bind logout elements
  document.addEventListener("click", function (e) {
    const el = e.target.closest("[data-action='logout'], .logout-btn, #logoutLink");
    if (el) {
      e.preventDefault();
      logout();
    }
  });

  window.AES_AUTH = { getRole, setSession, clearSession, requireRole, logout, gotoAuth };
})();
