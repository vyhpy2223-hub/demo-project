
    // Bind auth buttons inside injected sidebar
    function bindAuthButtons() {
        const role = (window.AES_AUTH && AES_AUTH.getRole) ? AES_AUTH.getRole() : "";
        const loginBtn = document.querySelector('.login-btn');
        const signupBtn = document.querySelector('.signup-btn');

        const gotoAuth = () => window.location.href = '../auth/index.html';

        if (loginBtn) {
            if (role) {
                loginBtn.textContent = 'Đăng xuất';
                loginBtn.onclick = (e) => { e.preventDefault(); AES_AUTH.logout(); };
            } else {
                loginBtn.onclick = (e) => { e.preventDefault(); gotoAuth(); };
            }
        }
        if (signupBtn) {
            if (role) {
                signupBtn.style.display = 'none';
            } else {
                signupBtn.onclick = (e) => { e.preventDefault(); gotoAuth(); };
            }
        }
    }

async function loadHTML(id, file) {
    const res = await fetch(file);
    const html = await res.text();
    document.getElementById(id).innerHTML = html;
}

document.addEventListener('DOMContentLoaded', async () => {
    await loadHTML('sidebar', 'partials/sidebar.html');
    bindAuthButtons();
    await loadHTML('footer', 'partials/footer.html');

    await loadHTML('hero', 'modules/hero.html');
    await loadHTML('progress', 'modules/progress.html');
    await loadHTML('ai-features', 'modules/ai-features.html');
    await loadHTML('learner-features', 'modules/learner-features.html');
    await loadHTML('cta', 'modules/cta.html');

    // Mount progress UI
    if (typeof renderProgress === 'function') {
        renderProgress('progress-mount');
    }
});
